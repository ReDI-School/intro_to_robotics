# MotorShield

## Description
The class helps to deal with Arduino Motor Shield R3 with two DC motors connected
